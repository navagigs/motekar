 <div class="page-header bg-white">
            <div class="breadcrumb">
              <a href="<?php echo site_url();?>android">Home</a><span>路</span>Info
            </div>
            <h1 class="page-title">Info</h1>
          
                   1. Pembeli melakukan pemesanan.
                   <br>
                   2. Setelah melakukan pemesanan pembeli akan mempunyai nomor Invoices.
                   <br>
                   3. Setelah itu pembeli melakukan pembayaran via trasfer Rek : 0044-49494-4949-499.
                   <br>
                   4. Setelah melakukan pembayaran, harap Konfirmasi Pembayaran.
                   <br>
                   5. Barang yang sudah di beli tidak dapat ditukar atau dikembalikan.
  </div>