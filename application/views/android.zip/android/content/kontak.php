 <div class="page-header bg-white">
            <div class="breadcrumb">
              <a href="<?php echo site_url();?>android">Home</a><span>·</span>Kontak
            </div>
            <h1 class="page-title">Kontak</h1>
          Kontak Motekar
  </div>